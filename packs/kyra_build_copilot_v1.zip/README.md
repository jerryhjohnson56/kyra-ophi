# Kyra Build Copilot — v1.0

A built‑in AI operator for **Kyra Build Control**. Chat with it to:
- Check pool **status**, run **once**, **start/stop** the loop.
- Inspect recent **logs**, list **open PRs**, open URLs.
- Claim next item and set **language‑aware** build/test path.
- Generate **summaries** and **fix plans** for failing jobs.

Uses **local Ollama** by default (no cloud needed). Everything runs on your machine.

## Quick install (overlay on top of kyra_build_control_v1)
```bash
unzip kyra_build_copilot_v1.zip -d app/kyra-control/
# now you have src/copilot/* and prompts/*

# add the panel to the UI:
# 1) open app/kyra-control/src/App.tsx
# 2) import and render <CopilotPanel />
#    (see "Wire the UI" below)
npm i   # inside app/kyra-control
npm run tauri dev
```

### Wire the UI (edit `app/kyra-control/src/App.tsx`)
Add:
```tsx
import { CopilotPanel } from "./copilot/CopilotPanel"
...
<div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, padding:12}}>
  <div>
    {/* existing panels ... */}
  </div>
  <div>
    <CopilotPanel />
  </div>
</div>
```

### Configure model
Create/extend `.env` in `app/kyra-control`:
```
KYRA_REPO_ROOT=/Users/<you>/code/kyra-ophi
KYRA_COPILOT_OLLAMA=http://127.0.0.1:11434
KYRA_COPILOT_MODEL=qwen2.5-coder:7b
```
> Use any Ollama model you like; coder‑tuned recommended for code actions.

### Privacy
- No data leaves your machine unless **you** authorize a `gh` or `git` operation that talks to GitHub.
- Copilot proposes actions first; **you confirm** before execution.
