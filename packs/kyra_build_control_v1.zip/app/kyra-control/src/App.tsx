import React, { useEffect, useState } from "react"
import { poolStatus, poolOnce, poolStart, poolStop } from "./lib/api"
import { ControlBar } from "./components/ControlBar"
import { StatusBar } from "./components/StatusBar"
import { QueueTable } from "./components/QueueTable"
import { LogViewer } from "./components/LogViewer"
import { ConfigEditor } from "./components/ConfigEditor"
import { PRList } from "./components/PRList"

const REPO = (import.meta as any).env?.KYRA_REPO_ROOT || process.env.KYRA_REPO_ROOT || ""

export default function App(){
  const [status,setStatus] = useState<any>({})
  const [busy,setBusy] = useState(false)
  const [log,setLog] = useState("")

  async function refresh(){
    const out = await poolStatus(REPO)
    try{ setStatus(JSON.parse(out.stdout)) }catch{}
  }
  useEffect(()=>{ refresh(); const id=setInterval(refresh, 3000); return ()=>clearInterval(id) }, [])

  const once = async ()=>{ setBusy(true); const out = await poolOnce(REPO); setBusy(false); setLog(out.stdout + out.stderr) }
  const start = async ()=>{ setBusy(true); const out = await poolStart(REPO); setBusy(false); setLog(out.stdout + out.stderr); await refresh() }
  const stop = async ()=>{ setBusy(true); const out = await poolStop(REPO); setBusy(false); setLog(out.stdout + out.stderr); await refresh() }

  return (
    <div style={{fontFamily:'Inter, ui-sans-serif, system-ui', background:'#0a0a0a', color:'#efefef', height:'100vh'}}>
      <h2 style={{padding:12}}>Kyra Build Control</h2>
      <StatusBar status={status} />
      <ControlBar busy={busy} onOnce={once} onStart={start} onStop={stop} />
      <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, padding:12}}>
        <div>
          <h3>Logs</h3>
          <LogViewer text={log} />
          <ConfigEditor root={REPO} />
        </div>
        <div>
          <PRList prs={status.prs||[]} />
          <h3>Queue (preview)</h3>
          <QueueTable items={[]} />
          <div style={{opacity:.7, fontSize:12}}>Queue will be sourced from manifest/telemetry in a later bump.</div>
        </div>
      </div>
    </div>
  )
}
