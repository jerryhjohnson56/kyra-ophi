import React from "react"
export function QueueTable(props:{items:any[]}){
  const items = props.items || []
  return (
    <table style={{width:'100%', color:'#ddd'}}>
      <thead><tr><th>ID</th><th>Title</th><th>Lang</th><th>Status</th></tr></thead>
      <tbody>
        {items.map((r,i)=>(
          <tr key={i}><td>{r.id}</td><td>{r.title}</td><td>{r.lang}</td><td>{r.status}</td></tr>
        ))}
      </tbody>
    </table>
  )
}
