#!/usr/bin/env python3
import argparse, json, os, subprocess, sys, pathlib, time, re

REPO = os.environ.get("KYRA_REPO_ROOT", os.getcwd())
LOGS = pathlib.Path(REPO)/"logs"
LOGS.mkdir(parents=True, exist_ok=True)
TELE = pathlib.Path(REPO)/"telemetry"
TELE.mkdir(parents=True, exist_ok=True)
STATE = TELE/"state.json"

def run(cmd, cwd=REPO, check=True):
    print("+", " ".join(cmd))
    return subprocess.run(cmd, cwd=cwd, check=check, text=True, capture_output=True)

def write_state(d):
    STATE.write_text(json.dumps(d, indent=2))

def read_state():
    if STATE.exists(): return json.loads(STATE.read_text())
    return {"started": int(time.time()), "last": None}

def status():
    s = read_state()
    pid = None
    pidfile = pathlib.Path(REPO)/".kyra_pool.pid"
    if pidfile.exists():
        try:
            pid = int(pidfile.read_text().strip())
            os.kill(pid, 0)
            s["loop_running"] = True
            s["pid"] = pid
        except Exception:
            s["loop_running"] = False
            s["pid"] = None
    else:
        s["loop_running"] = False
        s["pid"] = None

    # Active claim?
    claim = None
    for p in pathlib.Path(REPO/"stubs"/"items").glob("*/CLAIM.json"):
        try:
            data = json.loads(p.read_text())
            if data.get("owner"):
                claim = data
        except Exception:
            pass
    s["active_claim"] = claim

    # Open PRs (best-effort, requires gh)
    try:
        pr = run(["gh","pr","list","--state","open","--json","number,title,headRefName,webUrl"], check=False)
        if pr.returncode==0:
            s["prs"] = json.loads(pr.stdout)
    except Exception:
        s["prs"] = []
    return s

def run_once():
    out = run(["python3","scripts/pool_worker.py","--config","pool_config.yaml","--once"], check=False)
    rec = {"ts": int(time.time()), "cmd":"once", "rc": out.returncode, "stdout": out.stdout[-8000:], "stderr": out.stderr[-8000:]}
    (TELE/"telemetry.jsonl").open("a").write(json.dumps(rec)+"\n")
    write_state({"last": rec, **read_state()})
    return rec

def start_loop():
    sh = run(["bash","scripts/start_pool.sh"], check=False)
    return {"rc": sh.returncode, "out": sh.stdout+sh.stderr}

def stop_loop():
    sh = run(["bash","scripts/stop_pool.sh"], check=False)
    return {"rc": sh.returncode, "out": sh.stdout+sh.stderr}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("fn", choices=["status","once","start","stop"])
    args = ap.parse_args()
    if args.fn=="status": print(json.dumps(status(), indent=2))
    elif args.fn=="once":  print(json.dumps(run_once(), indent=2))
    elif args.fn=="start": print(json.dumps(start_loop(), indent=2))
    elif args.fn=="stop":  print(json.dumps(stop_loop(), indent=2))

if __name__=="__main__":
    main()
