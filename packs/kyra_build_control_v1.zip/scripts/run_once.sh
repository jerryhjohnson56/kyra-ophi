#!/usr/bin/env bash
set -euo pipefail
REPO="${KYRA_REPO_ROOT:-$PWD}"
cd "$REPO"
python3 scripts/pool_worker.py --config pool_config.yaml --once
