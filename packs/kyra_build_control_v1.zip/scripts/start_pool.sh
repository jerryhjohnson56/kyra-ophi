#!/usr/bin/env bash
set -euo pipefail
REPO="${KYRA_REPO_ROOT:-$PWD}"
cd "$REPO"
if [[ -f .kyra_pool.pid ]] && ps -p "$(cat .kyra_pool.pid)" >/dev/null 2>&1; then
  echo "Pool already running with PID $(cat .kyra_pool.pid)"; exit 0
fi
( bash scripts/pool_loop.sh > logs/pool_loop.out 2>&1 ) &
echo $! > .kyra_pool.pid
echo "Started pool loop PID $(cat .kyra_pool.pid)"
