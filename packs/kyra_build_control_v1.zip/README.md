# Kyra Build Control — v1.0

A novice‑friendly desktop dashboard to **watch and steer** your local AI pool while it builds the repo.

### Highlights
- Start/Stop **pool loop** and **Run once**.
- Live **queue**, **active job**, **logs**, **PR links**, **errors**.
- Click‑to‑edit `pool_config.yaml` in the UI.
- Works on macOS (Apple Silicon / Intel). Uses **Tauri + React** (lightweight, fast).

### Quick Start (macOS)
```bash
# 0) prerequisites (already installed earlier for your worker)
brew install python git jq
pip3 install pyyaml pytest pyflakes

# 1) unpack into your repo root (next to scripts/, manifest.json, etc.)
unzip kyra_build_control_v1.zip -d .

# 2) install UI deps (you can use npm, pnpm, or yarn)
cd app/kyra-control
npm i  # or: pnpm i / yarn

# 3) set repo path + token placeholders
cp .env.example .env
# edit .env to point to your repo path and python binary

# 4) run dev UI
npm run tauri dev

# 5) optional: build the app
npm run tauri build
```

> This app **does not modify** your worker scripts. It just calls them safely and shows status.

See `docs/Build_Control_User_Guide.md` for screenshots and UX.
