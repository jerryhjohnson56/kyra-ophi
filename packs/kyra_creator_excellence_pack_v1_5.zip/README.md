# Kyra Creator Excellence Pack — v1.5

**What’s new vs v1.4**
- **React Asset Browser hook menu** (`studio/panels/AssetBrowser/ui/AssetBrowserHooks.tsx`)
- **Universal native caller** for the hook runner (`studio/panels/AssetBrowser/ui/runHookClient.ts`)
  - Works with **Tauri** (via `@tauri-apps/api/shell`) or **Electron/Node** fallback
  - Optional browser dev server proxy as last resort
- **Context menu hook** (`studio/panels/AssetBrowser/ui/useContextMenu.ts`)
- Minimal types + example usage

## Drop‑in steps
```bash
# overlay onto creator/ (on top of v1.2–v1.4)
unzip kyra_creator_excellence_pack_v1_5.zip -d creator/

# (already done earlier) fetch ACES OCIO & install bridges
bash creator/scripts/fetch_aces_config.sh
bash creator/scripts/install_bridges.sh
bash creator/scripts/install_asset_browser_hooks.sh
```

## Wire into your panel (React/TypeScript)
```tsx
// Example: studio/panels/AssetBrowser/AssetBrowserPanel.tsx
import React from "react"
import { AssetBrowserHooks } from "./ui/AssetBrowserHooks"

export default function AssetBrowserPanel() {
  return (
    <div className="h-full flex">
      {/* ... your file grid/list here ... */}
      <AssetBrowserHooks
        hooksUrl={"/creator/studio/panels/AssetBrowser/menu.hooks.json"}
        projectRoot={process.cwd()} // or pass resolved repo path
      />
    </div>
  )
}
```

### Tauri allowlist (if using Tauri)
Add to `tauri.conf.json`:
```json
{
  "tauri": {
    "allowlist": {
      "shell": {
        "all": false,
        "open": false,
        "scope": [{
          "name": "python3",
          "cmd": "python3"
        }]
      }
    }
  }
}
```

### Electron fallback
No config needed; we try `window.require('child_process')` safely.

### Dev server proxy fallback
Set `KYRA_HOOK_PROXY=http://localhost:5173/kyrarun` and run a tiny dev server that executes the hook runner (for browser‑only previews).

---

This UI reads `menu.hooks.json` from v1.4 and dispatches to `creator/scripts/run_hook.py` (v1.4), which in turn calls the ACES‑aware send‑to scripts from v1.3.
