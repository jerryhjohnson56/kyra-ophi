# Kyra Build Suite + Copilot UI — v1.1

Desktop dashboard (Tauri + React) + local Copilot + pool control scripts and auto‑fixers.

## Prereqs (macOS)
```bash
brew install git python jq node
pip3 install pyyaml pytest pyflakes
curl https://sh.rustup.rs -sSf | sh -s -- -y     # optional for Rust stubs
npm i -g @tauri-apps/cli
```

## Install
```bash
# unpack at the ROOT of your repo (where manifest.json & scripts/ live)
unzip kyra_build_suite_plus_copilot_ui_v1_1.zip -d .

# one-time preflight — safe/idempotent
python3 scripts/fix_all_stubs.py
```

## Run the dashboard
```bash
cd app/kyra-control
npm i
cp .env.example .env
# edit .env:
#   KYRA_REPO_ROOT=/Users/<you>/code/kyra-ophi
#   KYRA_COPILOT_OLLAMA=http://127.0.0.1:11434
#   KYRA_COPILOT_MODEL=qwen2.5-coder:7b

npm run tauri dev
```

### What you can do
- **Run once / Start loop / Stop loop** (pool control)
- **Preflight Fix** (auto-fix common stub issues before runs)
- **Config editor** for `pool_config.yaml`
- **Log viewer**, **PR list**
- **Copilot chat** for natural-language control (“run once”, “status”, “show logs”, “claim next”)
