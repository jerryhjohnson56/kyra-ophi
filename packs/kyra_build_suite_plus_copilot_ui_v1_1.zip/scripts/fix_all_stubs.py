#!/usr/bin/env python3
from auto_fixers import main
if __name__=="__main__":
    main()
