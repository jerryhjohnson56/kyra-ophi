# OphiCache — Local LAN Cache for Kyra Models & Packs (v1)
Generated: 2026-01-04T08:04:28.164820Z


**Purpose:** Speed up installs/updates for a pool by caching Kyra **packs** (models, content, updates)
on a LAN node (Mac mini, base station, or Linux box). Acts as:
- **Content-Addressable Store (CAS)** with SHA256 verification
- **LAN mirror** for signed `.kpack` bundles (no internet once cached)
- **Prefetch** target (warm popular packs before you install)
- **Simple REST API** compatible with pool workers and the installer

## Quick start (macOS/Linux)
```bash
# 1) Install deps
python3 -m venv .venv && source .venv/bin/activate
pip install -r services/ophicache/requirements.txt

# 2) Configure storage + upstreams
cp services/ophicache/config.sample.yaml services/ophicache/config.yaml
# (edit paths/ports/upstreams as needed)

# 3) Run the server
python3 services/ophicache/ophicache_server.py --config services/ophicache/config.yaml

# 4) Pre-warm cache (optional)
bash scripts/cache/prefetch.sh http://127.0.0.1:7060 services/ophicache/prefetch.sample.yaml

# 5) Point Kyra tools at it (pool worker / installer)
export OPHICACHE_URL=http://<cache-ip>:7060
# pool_worker.py will prefer OPHICACHE_URL for pack/model downloads if you apply the patch below.
```

## API (minimal)
- `GET /v1/index` → list cached artifacts
- `GET /v1/packs/{sha256}?name=<fname>` → stream by digest (supports Range)
- `POST /v1/prefetch` → body: {"items":[{"url":"...","sha256":"...","name":"..."}]}
- `GET /v1/metrics` → JSON counters (hits, misses, bytes_served)
- `POST /v1/ingest_local` → ingest a local `.kpack` file (multipart)

## Storage layout
```
<storage_root>/
  blobs/sha256/<first2>/<sha256>        # CAS blobs
  names/<name>.json                     # manifest entries mapping names->sha256
  db/state.json                         # lightweight counters
```

## Systemd (Linux) / Launchd (macOS)
- See `services/ophicache/systemd/ophicache.service`
- See `services/ophicache/launchd/local.kyra.ophicache.plist`

## Pool Worker patch (env-driven)
Add near your download function so workers try the cache first:
```python
import os, urllib.parse
cache = os.environ.get("OPHICACHE_URL")
def cache_url(orig_url, sha256=None, name=None):
    if not cache: return None
    q = urllib.parse.urlencode({k:v for k,v in {"sha256":sha256, "name":name}.items() if v})
    return f"{cache}/v1/proxy?url={urllib.parse.quote(orig_url, safe='')}&{q}" if q else f"{cache}/v1/proxy?url={urllib.parse.quote(orig_url, safe='')}"
# then if cache_url(...) returns a URL, attempt it first; fallback to orig_url on 404.
```

## USB export/import (air-gapped)
- `scripts/cache/export_usb.sh` creates `/kpack_shelf/` with manifests + blobs
- `scripts/cache/import_usb.sh` imports a `/kpack_shelf/` into the CAS

## Security & Integrity
- All resources keyed by **SHA256**, verified on fetch and before serve.
- Intended to cache **signed Kyra packs**; signatures/metadata are preserved.
- Runs on your LAN; no external telemetry.
