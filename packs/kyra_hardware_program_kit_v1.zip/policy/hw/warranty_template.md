# Warranty (Template)
- Coverage: 24 months limited hardware warranty.
- Battery/accessories: 12 months.
- Exclusions: accidental damage, liquid ingress, user mods.
- Process: contact → RMA number → ship → repair/replace.
- Data: user responsible for backups; we provide privacy-safe wipe tools.
