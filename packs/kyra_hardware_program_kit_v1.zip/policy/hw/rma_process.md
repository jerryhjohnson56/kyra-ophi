# RMA Process (Template)
1. Remote triage with diagnostic bundle.
2. Issue RMA ID; provide shipping label.
3. Incoming inspection; reproduce issue with bench suite.
4. Repair/replace; run burn-in tests; ship back; bench results attached.
