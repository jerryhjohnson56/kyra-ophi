# Firmware Update Protocol (Outline)
- Signed update capsules; rollback counters
- Safe staging; verify hash/signature; apply on reboot
- Recovery entry if last boot failed twice
- Logs exported to Weave provenance for field diagnostics
