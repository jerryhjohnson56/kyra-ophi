# Marketing Copy Blocks (Starter)
**Made for creators & builders.** Kyra hardware ships tuned for the OS: fast UI, quiet thermals, and models ready offline.

**Go live in minutes.** Persona camera + mic array pre-calibrated; overlays included.

**Fast, even when it’s busy.** UI gets priority; AI tasks run in their own lane.

**You own it.** Offline-first, signed updates, one-tap recovery.

