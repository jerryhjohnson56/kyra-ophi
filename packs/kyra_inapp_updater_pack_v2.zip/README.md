# Kyra Build Suite — In‑App Updater v2 (Background Download + Verify + Launch)

This pack upgrades the updater to:
- **Background download** with live progress
- **SHA‑256 verification** against feed hash
- **1‑click launch** of installer (DMG/MSI/EXE/AppImage/DEB)
- **Event log** (`logs/updater.log`) with fallback to console

Drop this at your **repo root**, then copy files into `app/kyra-control` as shown below.

## Files to copy / merge
- `app/kyra-control/src/updater/UpdateServiceV2.ts`
- `app/kyra-control/src/updater/hash.ts`
- `app/kyra-control/src/updater/platform.ts`
- `app/kyra-control/src/updater/Installer.ts`
- `app/kyra-control/src/updater/UpdaterProviderV2.tsx`
- `app/kyra-control/src/components/UpdateModal.tsx`
- `app/kyra-control/src/components/UpdateBanner.tsx` (optional mini-banner)
- `app/kyra-control/src/hooks/useUpdater.ts` (re‑export V2)
- `app/kyra-control/src/styles/updater.css`
- Append `app/kyra-control/.env.example.append` to your `.env`

## Wire it in
In your React root (e.g. `src/main.tsx`):
```tsx
import { UpdaterProviderV2 } from "./updater/UpdaterProviderV2";
import UpdateModal from "./components/UpdateModal";
import UpdateBanner from "./components/UpdateBanner"; // optional

ReactDOM.createRoot(document.getElementById("root")!).render(
  <UpdaterProviderV2>
    <UpdateBanner />
    <UpdateModal />
    <App />
  </UpdaterProviderV2>
);
```

## Usage
- On boot + every 6h, we check the feed (`/updates/latest.json`).
- If newer version: small **banner** appears, and **Update Modal** can be opened.
- Modal supports **Download → Verify → Install**. Progress and errors are shown.
- All steps are logged to `logs/updater.log` (within the repo if writable; otherwise app data dir).

## Feed format
Same as v1:
```json
{
  "version":"v0.1.0",
  "notes":"...",
  "assets":[{"name":"KyraControl-0.1.0.dmg","url":"https://...","sha256":"..."}]
}
```
Keep the `sha256` whenever possible for verification.
