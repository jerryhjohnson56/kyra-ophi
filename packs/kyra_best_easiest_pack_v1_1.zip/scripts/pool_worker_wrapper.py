#!/usr/bin/env python3
import argparse, os, subprocess, sys, time, json
from pathlib import Path

REPO = Path(os.environ.get("KYRA_REPO_ROOT", os.getcwd()))
LOG = REPO/"logs"; LOG.mkdir(exist_ok=True, parents=True)

def run(cmd, **kw):
    print("+", " ".join(cmd), flush=True)
    return subprocess.run(cmd, text=True, capture_output=True, **kw)

def preflight_fix():
    out = run(["python3","scripts/fix_all_stubs.py"])
    print(out.stdout, end="")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="pool_config.yaml")
    ap.add_argument("--once", action="store_true")
    args = ap.parse_args()

    preflight_fix()

    while True:
        proc = run(["python3","scripts/pool_worker.py","--config",args.config] + (["--once"] if args.once else []))

        (REPO/"telemetry").mkdir(parents=True, exist_ok=True)
        with (REPO/"telemetry"/"telemetry.jsonl").open("a") as f:
            rec = {"ts": int(time.time()), "rc": proc.returncode, "stdout": proc.stdout[-4000:], "stderr": proc.stderr[-4000:]}
            f.write(json.dumps(rec)+"\n")

        blob = (proc.stdout or "") + "\n" + (proc.stderr or "")
        if ("unknown start of token: `" in blob) or ("expected one of `!` or `::`, found `serde_json`" in blob) or ("invalid syntax ```python" in blob):
            print("Auto-fix: common stub issues detected; running fixers again.", flush=True)
            preflight_fix()

        if args.once: break
        time.sleep(1.5)

if __name__=="__main__":
    main()
