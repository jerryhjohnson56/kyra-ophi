# Kyra — Best & Easiest Pack v1.1

This adds **auto-fixers** (common stub issues), a **wrapper** runner (no edits to pool_worker.py),
and **one-click** scripts to start/stop/run once. Use it with your existing repo.

## Install
```bash
# In your repo root (next to scripts/, manifest.json, etc.):
unzip kyra_best_easiest_pack_v1_1.zip -d .
```

## Quick start
```bash
# 1) one-time preflight (safe/idempotent): strip code fences, fix 'se serde', scaffold Cargo
python3 scripts/fix_all_stubs.py

# 2) run once
bash scripts/run_once.sh

# 3) start the loop
bash scripts/start_pool.sh

# 4) stop any time
bash scripts/stop_pool.sh
```
