
Write minimal tests for the implemented stub. Prefer pure function assertions.

Context:
{{context}}

Target test dir: {{test_dir}}


DO NOT wrap your answer in code fences (no ``` or ~~~).
Output ONLY the complete file content for the target file.

