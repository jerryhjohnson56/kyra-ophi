
You will fix a build error without changing the public API.

- Keep the same function names and signatures.
- Simplify logic to satisfy compiler/linter.

Context (error excerpts + file):
{{context}}

Target file: {{target_file}}


DO NOT wrap your answer in code fences (no ``` or ~~~).
Output ONLY the complete file content for the target file.

