
Implement a tiny C program with JSON stdout.

Rules:
- main() must print exactly one JSON object and a trailing newline.
- No file/network IO.
- Use portable C99.

Context:
{{context}}

Target file path: {{target_file}}


DO NOT wrap your answer in code fences (no ``` or ~~~).
Output ONLY the complete file content for the target file.

