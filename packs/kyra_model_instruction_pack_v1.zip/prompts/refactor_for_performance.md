
Refactor for baseline performance while preserving exact behavior.

- No external deps.
- Keep public API and file structure.

Context:
{{context}}

Target file: {{target_file}}


DO NOT wrap your answer in code fences (no ``` or ~~~).
Output ONLY the complete file content for the target file.

