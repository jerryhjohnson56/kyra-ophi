
# Branch & PR Conventions

- Branch: `worker/<host>/<ITEM_ID>`
- Commit: `feat(<ITEM_ID>): <short>`
- PR: auto-created by worker. Reviewers merge after CI green.
