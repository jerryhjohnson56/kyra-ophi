fn main(){ println!("kyra-gateway stub"); }
