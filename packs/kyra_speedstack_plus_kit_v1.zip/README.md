# Speed Stack PLUS — How to use
1) Add crate: `crates/kyra_directio` and examples in `samples/` to the repo.
2) CI: build `kyra_directio`; compile (or just lint) `samples/gds_sample.cpp` on NVIDIA runners.
3) For OphiDrive: wire host lib at `storage/ophidrive/host/ophidrive_host.py` and share device vendor docs.
4) Auto‑tuner: install `services/auto_tune/*.service,timer` and run once on first boot.
