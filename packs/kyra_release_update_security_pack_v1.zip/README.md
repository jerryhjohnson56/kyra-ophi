# Kyra — Release, Auto‑Update & Supply‑chain Pack (v1)

Drop these files at the **root** of your repo. This adds:
- **Release workflow** (`release-publish.yml`) → builds for macOS/Win/Linux, signs, checksums, SBOM, uploads a GitHub Release on **tag** push (e.g. `v1.2.3`).
- **Auto‑Update channel** (`gh-pages-updates.yml`) → publishes `updates/<version>.json` + `updates/latest.json` to **GitHub Pages**.
- **Provenance/Attestations**:
  - **SLSA provenance** (`slsa-provenance.yml`) for release artifacts
  - **Cosign keyless blob signatures** (`cosign-sign.yml`) for built installers (optional)
- **Helper scripts** to collect artifacts & generate JSON feed.

## Set these once
GitHub → **Settings → Pages**: enable Pages on branch `gh-pages`, folder `/`.

GitHub → **Settings → Secrets and variables → Actions → New repository secret** (optional but recommended):
- **Signing:** (use ones you already set up in the previous pack)
  - macOS: `APPLE_TEAM_ID`, `APPLE_ID`, `APPLE_APP_PASS` *or* `APPLE_API_KEY_BASE64`, `APPLE_API_KEY`, `APPLE_API_ISSUER`
  - Windows: `WIN_CERT_PFX_BASE64`, `WIN_CERT_PASSWORD`
  - Linux: `LINUX_GPG_PRIVATE_KEY`, `LINUX_GPG_PASSPHRASE`
- **Cosign (optional):** none needed for **keyless** mode (uses GitHub OIDC). If you want key‑pair, add `COSIGN_PRIVATE_KEY`, `COSIGN_PASSWORD`.
- **Releases:** none required.

## How to cut a release
```bash
git tag v0.1.0
git push origin v0.1.0
```
This triggers:
1) **release-publish.yml** → build/sign/SBOM/checksums for 3 OSes, create Release, upload assets
2) **gh-pages-updates.yml** → writes `updates/v0.1.0.json` + `updates/latest.json` to Pages
3) **slsa-provenance.yml** → generate provenance
4) **cosign-sign.yml** (optional) → keyless sign built installers

See `docs/Release_Process.md` for details.
