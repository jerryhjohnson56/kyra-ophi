# Kyra Build Suite + Copilot — v1.1 (Scripts Edition)

This pack restores the **pool control scripts** and **auto-fixers** so your local AIs can keep coding smoothly.

## Quick start (macOS)
```bash
brew install git python jq
pip3 install pyyaml pytest pyflakes

# unpack into your repo root (where scripts/ & manifest.json live)
unzip kyra_build_suite_plus_copilot_v1_1.zip -d .

# 1) preflight (safe/idempotent)
python3 scripts/fix_all_stubs.py

# 2) single cycle
bash scripts/run_once.sh

# 3) start/stop continuous loop
bash scripts/start_pool.sh
bash scripts/stop_pool.sh
```
